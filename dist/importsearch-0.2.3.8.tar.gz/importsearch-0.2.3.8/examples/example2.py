import importsearch

def main():
    target_file = 'sample_dir/main.py'
    target_file = '/home/eto/projects/ImportSearch/examples/sample_dir/main.py'

    importsearch.search(target_file)



if __name__ == '__main__':
    main()