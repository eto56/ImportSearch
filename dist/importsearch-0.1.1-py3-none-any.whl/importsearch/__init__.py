

# src/importsearch/__init__.py

from .core import importsearch

__all__ = ["importsearch"]
